__all__ = ['ipapi']
from .ipapi import location
